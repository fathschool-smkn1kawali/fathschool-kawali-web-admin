<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Bahasa Paginasi
    |--------------------------------------------------------------------------
    |
    | Baris bahasa berikut digunakan oleh pustaka paginator untuk membuat
    | tautan paginasi sederhana. Anda bebas mengubahnya sesuai dengan
    | kebutuhan aplikasi Anda agar lebih sesuai.
    |
    */

    'previous' => '&laquo; Sebelumnya',
    'next' => 'Berikutnya &raquo;',

];
